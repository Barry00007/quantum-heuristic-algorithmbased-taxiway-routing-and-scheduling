import inputData
import shortpath
import math
import csv
import numpy as np
import ACO
import time
import QACA
import main_ACO
data= main_ACO.readin("data/5")



def ACO1(data, plan_num):
    start_point = int(data.plan[plan_num][1])
    end_point = int(data.plan[plan_num][3])
    city_num = len(data.coordinate)
    s_path = shortpath.ShortPath(data.vertex, data.coordinate, data.plan[plan_num])
    origin_path = s_path.findpath(str(start_point), str(end_point))
    origin_path = [int(x) for x in origin_path]

    everyLength = []
    with open("data/1222/shortEveryLength.csv", 'a', newline='') as csvfile:
        everyLength.append(s_path.calculate_length(origin_path))
        writer = csv.writer(csvfile)
        writer.writerow(everyLength)
if __name__ == '__main__':
    for i in range(18):
        ACO1(data,i)