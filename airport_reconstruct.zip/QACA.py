# -*- coding: utf-8 -*-
import random
import copy
import shortpath
import math
# 参数
(ALPHA, BETA, RHO, Q) = (1.0, 0, 0.9, 100.0)
global theta
# 城市数，蚁群
(city_num, ant_num) = (50, 2)
start_point, end_point, speed = -1,-1,-1

def QACA_algrithm(data,plan_num):
    global distance_x,distance_y,distance_graph,pheromone_graph,start_point,end_point,speed,vertex,city_num,origin_path,theta


    distance_x = [x[1] for x in data.coordinate]
    distance_y = [x[2] for x in data.coordinate]
    start_point = int(data.plan[plan_num][1])
    end_point = int(data.plan[plan_num][3])
    speed = data.plan[plan_num][5]
    vertex = data.vertex
    city_num = len(data.coordinate)
    s_path = shortpath.ShortPath(data.vertex,data.coordinate,data.plan[plan_num])
    distance_graph = [[0.0 for col in range(city_num+1)] for raw in range(city_num+1)]
    pheromone_graph = [[1/math.sqrt(2) for col in range(city_num+1)] for raw in range(city_num+1)]
    origin_path = s_path.findpath(str(start_point),str(end_point))
    origin_path = [int(x) for x in origin_path]
    tsp = TSP()
    tsp.search_path(100)
    if tsp.best_ant.path[-1]==end_point:
        return tsp.best_ant.path
    else:
        return origin_path

# ----------- 蚂蚁 -----------
class Ant(object):

    # 初始化
    def __init__(self, ID):

        self.ID = ID  # ID
        self.__clean_data()  # 随机初始化出生点

    # 初始数据
    def __clean_data(self):

        self.path = []  # 当前蚂蚁的路径
        self.total_distance = 0.0  # 当前路径的总距离
        self.move_count = 0  # 移动次数
        self.current_city = -1  # 当前停留的城市
        self.open_table_city = [True for i in range(city_num+1)]  # 探索城市的状态

        city_index = start_point  # 出生点即为起点#########################
        self.current_city = city_index
        self.path.append(city_index)
        self.open_table_city[city_index] = False
        self.move_count = 1

    # 选择下一个城市
    def __choice_next_city(self):

        next_city = -1
        select_citys_prob = [0.0 for i in range(city_num+1)]  # 存储去下个城市的概率
        total_prob = 0.0

        # 获取去下一个城市的概率
        next_city_list1 = [x[1] for x in vertex if x[0]==self.current_city]
        next_city_list2 = [x[0] for x in vertex if x[1] == self.current_city]#双向图
        next_city_list=next_city_list1+next_city_list2
        if len(next_city_list)==0:
            return -1
        possibilities = 0
        # if end_point in next_city_list:
        #     return end_point
        for i in next_city_list:
            if self.open_table_city[i]:
                possibilities += 1
                try:
                    # 计算概率：与信息素浓度成正比，与距离成反比
                    select_citys_prob[i] = pow(pheromone_graph[self.current_city][i], ALPHA)/pow(distance_graph[i][end_point]/10000,BETA)
                    total_prob += select_citys_prob[i]
                except ZeroDivisionError as e:
         #           print('Ant ID: {ID}, current city: {current}, target city: {target}'.format(ID=self.ID,
          #                                                                                      current=self.current_city,
          #                                                                                      target=i))
                #    sys.exit(1)
                    continue
        if possibilities==0:
            return -1
        # 轮盘选择城市
        if total_prob > 0.0:
            # 产生一个随机概率,0.0-total_prob
            temp_prob = random.uniform(0.0, total_prob)
            for i in next_city_list:
                if self.open_table_city[i]:
                    # 轮次相减
                    temp_prob -= select_citys_prob[i]
                    if temp_prob < 0.0:
                        next_city = i
                        break

        return next_city

    # 计算路径总距离
    def __cal_total_distance(self):

        temp_distance = 0.0

        for i in range(1, len(self.path)):
            start, end = self.path[i], self.path[i - 1]
            temp_distance += distance_graph[start][end]

        # 回路
        end = self.path[0]
        temp_distance += distance_graph[start][end]
        self.total_distance = temp_distance

    # 移动操作
    def __move(self, next_city):

        self.path.append(next_city)
        self.open_table_city[next_city] = False
        self.total_distance += distance_graph[self.current_city][next_city]
        self.current_city = next_city
        self.move_count += 1

    # 搜索路径
    def search_path(self, endpoint):

        # 初始化数据
        self.__clean_data()

        # 搜素路径，直到无法前进
        while self.move_count < city_num:
            # 移动到下一个城市
            next_city = self.__choice_next_city()
            self.__move(next_city)
            if next_city == endpoint or next_city==-1:
                break

        # 计算路径总长度
        self.__cal_total_distance()


# ----------- TSP问题 -----------

class TSP:
    def __init__(self, n=city_num):
        self.n = n

        # 计算城市之间的距离
        for i in range(city_num):
            for j in range(city_num):
                temp_distance = pow((distance_x[i] - distance_x[j]), 2) + pow((distance_y[i] - distance_y[j]), 2)
                temp_distance = pow(temp_distance, 0.5)
                distance_graph[i][j] = float(int(temp_distance + 0.5))

        # 初始城市之间的距离和信息素
        for i in range(city_num):
            for j in range(city_num):
                pheromone_graph[i][j] = 1/math.sqrt(2)
        # for i in range(1,len(origin_path)):
        #     start, end = origin_path[i - 1], origin_path[i]
        #     #初始化在最短路径留下更多信息素
        #     pheromone_graph[start][end] += 0.1
        #     pheromone_graph[end][start] = pheromone_graph[start][end]

        self.ants = [Ant(ID) for ID in range(ant_num)]  # 初始蚁群
        self.best_ant = Ant(-1)  # 初始最优解
        self.best_ant.total_distance = 1 << 31  # 初始最大距离
        self.iter = 1  # 初始化迭代次数

    # 开始搜索
    def search_path(self, max_generation):

        for i in range(max_generation):
            # 遍历每一只蚂蚁
            global theta
            if i<=max_generation/2:
                theta = 0.05 * math.pi
            elif i <=max_generation*3/4:
                theta = 0.1 * math.pi
            else:
                theta = 0.0025 * math.pi
            for ant in self.ants:
                # 搜索一条路径
                ant.search_path(end_point)
                # 与当前最优蚂蚁比较
                if ant.path[-1]==end_point and ant.total_distance < self.best_ant.total_distance:
                    # 更新最优解
                    self.best_ant = copy.deepcopy(ant)
            # 更新信息素
            self.__update_pheromone_gragh()
            # print(u"迭代次数：", self.iter, u"最佳路径总距离：", int(self.best_ant.total_distance))
            # print(self.best_ant.path)
            self.iter += 1



    # 更新信息素
    def __update_pheromone_gragh(self):

        # 获取每只蚂蚁在其路径上留下的信息素
        temp_pheromone = [[0.0 for col in range(city_num+1)] for raw in range(city_num+1)]
        for ant in self.ants:
            if ant.path[-1]==end_point:#如果正确 则留下信息素
                for i in range(1, len(ant.path)):
                    start, end = ant.path[i - 1], ant.path[i]
                    a=temp_pheromone[start][end]
                    temp_pheromone[start][end] = a * math.cos(-theta) - math.sqrt(1 - a * a) * math.sin(-theta)
                    temp_pheromone[end][start] = temp_pheromone[start][end]

        # 更新所有城市之间的信息素，旧信息素衰减加上新迭代信息素
        for i in range(city_num+1):
            for j in range(city_num+1):
                pheromone_graph[i][j] = pheromone_graph[i][j] * RHO + temp_pheromone[i][j]

# ----------- 程序的入口处 -----------

if __name__ == '__main__':
    tsp = TSP()
    tsp.search_path(10)