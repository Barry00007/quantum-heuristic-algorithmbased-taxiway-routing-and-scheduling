import matplotlib.pyplot as plt
def txt_to_matrix(filename):#读取文件，转换成列表
    file = open(filename,"r")
    lines=file.readlines()
    lists=[]
    for fields in lines:
        fields = fields.strip()
        fields = fields.strip("[]")
        fields = fields.split(" ")
        temp = []
        for a in fields:
            temp.append(int(a))
        lists.append(temp)
    return(lists)

def input_plan(filename):
    file = open(filename,"r")
    lines=file.readlines()
    lists=[]
    for fields in lines:
        fields = fields.strip()
        fields = fields.strip("[]")
        fields = fields.split(" ")
        temp = []
        for a in fields:
            temp.append(str(a))
        lists.append(temp)
    return(lists)

if __name__ == '__main__': #节点-路径画图
    vertex = txt_to_matrix("data/v50/vertex.txt")
    coordinate = txt_to_matrix("data/v50/coordinate.txt")
    xValue=[x[1] for x in coordinate]
    yValue=[x[2] for x in coordinate]
    plt.scatter(xValue, yValue)
    for i in vertex:
        tempX=i[0]-1
        tempY=i[1]-1
        plt.plot([coordinate[tempX][1], coordinate[tempY][1]], [coordinate[tempX][2], coordinate[tempY][2]], color='k')
        # vec1=np.array([dis[tempX][1],dis[tempX][2]])
        # vec2 = np.array([dis[tempY][1], dis[tempY][2]])
        # print(i,[dis[tempX][1],dis[tempX][2]], [dis[tempY][1],dis[tempY][2]],np.sqrt(np.sum(np.square(vec1-vec2))))
        # print()
    for i in coordinate:
        plt.text(i[1]+10, i[2]+10, i[0])
    plt.show()


