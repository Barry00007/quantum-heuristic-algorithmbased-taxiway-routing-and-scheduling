import dijkstras
import numpy as np


def search_in_list(list, a1, a2):
    for i in list:
        if i[0] == a1 and i[1] == a2:
            return i

        if i[0] == a2 and i[1] == a1:
            return i

    return []


class ShortPath:
    def __init__(self, vertex, coordinate, plan):
        self.vertex = vertex
        self.coordinate = coordinate
        self.plan = plan
        self.TEMP = []
        i_num = 0
        for i in vertex:  # 计算邻接距离
            tempX = i[0] - 1
            tempY = i[1] - 1
            vec1 = np.array([coordinate[tempX][1], coordinate[tempX][2]])
            vec2 = np.array([coordinate[tempY][1], coordinate[tempY][2]])
            self.vertex[i_num].append(int(np.sqrt(np.sum(np.square(vec1 - vec2)))))
            i_num += 1
            self.TEMP.append(int(np.sqrt(np.sum(np.square(vec1 - vec2)))))

    def findpath(self, start, finish):  # 输入起点和终点，调用dijkstras算法计算最短路径 并输出

        d = dijkstras.Dijkstras() #可以换其他的

        Adjacency_List = []
        vertex = self.vertex

        for i in range(len(vertex)):
            Adjacency_List.append([vertex[i][0], vertex[i][1], self.TEMP[i]])
            Adjacency_List.append([vertex[i][1], vertex[i][0], self.TEMP[i]])
        Adjacency_List = sorted(Adjacency_List, key=lambda Adjacency_List: Adjacency_List[0])

        for i in range(len(Adjacency_List)):
            if i == 0:
                dic = {str(Adjacency_List[i][1]): self.TEMP[i]}
            else:
                if Adjacency_List[i][0] != Adjacency_List[i - 1][0]:
                    d.add_vertex(str(Adjacency_List[i - 1][0]), dic)
                    dic = {str(Adjacency_List[i][1]): Adjacency_List[i][2]}
                else:
                    dic[str(Adjacency_List[i][1])] = Adjacency_List[i][2]
                if i == len(Adjacency_List) - 1:
                    d.add_vertex(str(Adjacency_List[i][0]), dic)
        x = d.shortest_path(start, finish)[::-1]
        x.insert(0, start)
        return (x)

    def calculate_length(self, path):#计算每段路径的长度，各个节点之间的距离之和
        point_num = len(path)
        sum = 0
        for i in range(point_num - 1):
            this_len = search_in_list(self.vertex, int(path[i]), int(path[i + 1]))
            sum += this_len[2]
        return sum
