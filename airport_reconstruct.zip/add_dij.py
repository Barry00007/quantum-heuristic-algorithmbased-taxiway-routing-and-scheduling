import inputData
import LinkedList
import math
import time
import csv
import numpy as np
import ACO

max_generation = 1

def t2s(t):  # 字符串转秒
    h, m, s = t.strip().split(":")
    return int(h) * 3600 + int(m) * 60 + int(s)

class NodeInfo:#各个节点的信息，包括节点名，以及经过节点的飞机和时间
    def __init__(self,node):
        self.nodelist = [['0',LinkedList.LinkList()]]#插入节点0，使得节点编号和与i对应
        self.plane_time = []
        for i in range(len(node)):
            self.nodelist.append([node[i],LinkedList.LinkList()])

    def __add__(self, plane,vertex_time ):#vertex_time[0]:节点，[1]时间
        self.plane_time.append([plane,vertex_time])
        for i in range(len(vertex_time)):
            to_be_inserted = [plane,vertex_time[i][1]]
            head = self.nodelist[int(vertex_time[i][0])][1]
            self.nodelist[int(vertex_time[i][0])][1].sorted_insert([plane,vertex_time[i][1]])

class Data:
    def __init__(self):
        self.vertex = [] # 邻接表
        self.coordinate = [] # 各点坐标
        self.plan = []  # 起点 起始时间 终点 终止时间 速度

def readin(datapath):#根据路径读取数据
    data = Data()
    data.vertex = inputData.txt_to_matrix(datapath + "/vertex.txt")  # 邻接表
    data.coordinate = inputData.txt_to_matrix(datapath + "/coordinate.txt")  # 各点坐标
    data.plan = inputData.input_plan(datapath + "/plan.txt")  # 起点 起始时间 终点 终止时间 速度
    return data

class AirportPlan:
    data = readin("data/2")

    def __init__(self, plan):

        self.num = [int(x[0]) for x in plan]
        self.start_point = [x[1] for x in plan]
        self.start_time = [t2s(x[2]) for x in plan]
        self.finish_point = [x[3] for x in plan]
        self.finish_time = [t2s(x[4]) for x in plan]
        self.speed = [int(x[5]) for x in plan]

        x = np.array(self.start_time)
        self.priority = list(x.argsort())

        #初始化滑行时间和等待时间
        self.wait_time = [0]*len(self.num)
        self.path_time = []
        self.path=[]

        distance_x = [x[1] for x in data.coordinate]
        distance_y = [x[2] for x in data.coordinate]

        self.distance_graph = [[0.0 for col in range(len(data.coordinate) + 1)] for raw in range(len(data.coordinate) + 1)]
        for i in range(len(data.coordinate)):
            for j in range(len(data.coordinate)):
                temp_distance = pow((distance_x[i] - distance_x[j]), 2) + pow((distance_y[i] - distance_y[j]), 2)
                temp_distance = pow(temp_distance, 0.5)
                self.distance_graph[i][j] = float(int(temp_distance + 0.5))

    def calculate_length(self, tempPath):
        point_num = len(tempPath)
        sum = 0
        for i in range(point_num - 1):
            this_len = self.distance_graph[tempPath[i]][tempPath[i + 1]]
            sum += this_len
        return sum

    def calculate_time(self, path, plane_num):  # 不考虑冲突，按照规定时间从起点出发
        vertex_time = []  # 该飞机经过d path路径上各个节点以及经过的时间
        for i in range(len(path)):
            if i == 0:
                vertex_time.append([path[i], self.start_time[plane_num]+self.wait_time[plane_num]])
            else:
                tempPath=[int(path[i - 1]), int(path[i])]
                temp_distance = self.calculate_length(tempPath)
                i_time = vertex_time[i - 1][1] + temp_distance / self.speed[plane_num]#匀速
                vertex_time.append([ path[i], i_time ] )
        self.path_time.append(vertex_time)
        return vertex_time

    def wait(self,planeAndWaitTime):

        planeNum = [x[0] for x in planeAndWaitTime]
        waitTime = [x[1] for x in planeAndWaitTime]

        #用来去重 一架飞机所需要多次等待 只取一次等待时间最久的
        pN=[]
        wT=[]

        for pi in range(len(planeNum)):
            if planeNum[pi] in pN:
                index = pN.index(planeNum[pi])
                if wT[index]>waitTime[pi]:
                    continue
                else:
                    wT[index] = waitTime[pi]
            else:
                pN.append(planeNum[pi])
                wT.append(waitTime[pi])

        planeNum=pN
        waitTime=wT

        #修改path_time 即各个飞机的路径时间
        for i in range(len(planeNum)):#选中飞机
            self.wait_time[planeNum[i]]+=waitTime[i]
            for j in range(len(self.path_time[planeNum[i]])):
                self.path_time[planeNum[i]][j][1]+=waitTime[i]

        #修改各个节点被访问的时间
        for i in range(len(planeNum)):
            for j in range(len(self.path_time[planeNum[i]])):
                tempNode=self.path[planeNum[i]][j]
                node_info.nodelist[tempNode][1].removeById(planeNum[i])
            node_info.__add__(planeNum[i],ap.path_time[planeNum[i]])

def node_Conflict_Detection(node_info,plan):#判断点冲突
    node_conflict=[]
    for i in range(1,1+len(node)):
        plane_time_in_node = node_info.nodelist[i][1].to_List()
        if len(plane_time_in_node)<=1: #小于等于一架飞机经过该点，无需判断冲突
            continue
        for j in range(len(plane_time_in_node)-1):

            latePlane = plane_time_in_node[j+1][0]
            earlyPlane = plane_time_in_node[j][0]
            lateTime = plane_time_in_node[j+1][1]
            earlyTime = plane_time_in_node[j][1]

            time_interval = lateTime - earlyTime  # 两架飞机经过同一点的时间间隔(后一架飞机到点)
            early_speed = int(plan[plane_time_in_node[j][0]][-1])
            temp_distance = time_interval*early_speed
            if temp_distance<SAFE_DISTANCE:
                # 输出冲突
             #   print(i,":",plane_time_in_node[j],plane_time_in_node[j+1])

                node_conflict.append([i,plane_time_in_node[j],plane_time_in_node[j+1]])
    return node_conflict

def intersection_of_length2(list1,list2): #两端路径中相同的边(两个点)
    list1in2 = [x for x in list1 if x in list2] #list1中所有的包含在list2中的节点
    result=[]
    for x in range(len(list1in2)-1):
        x_index1 = list1.index(list1in2[x])
        x_index2 = list2.index(list1in2[x])
        if x_index2 == len(list2)-1:
            continue
        if list1in2[x+1]==list1[x_index1+1] and list1in2[x+1]==list2[x_index2+1]:
            result.append([list1in2[x],list1in2[x+1]])
    return result

def head_Conflict_Detection(node_info,all_path):#对头冲突
    reversed_all_path = []
    for i in range(len(all_path)):
        temp=all_path[i].copy()
        temp.reverse()
        reversed_all_path.append(temp)
    head_Conflict=[]
    for i in range(len(all_path)-1):#飞机i与后面所有的飞机进行匹配
        for j in range(i+1,len(all_path)):
            same_edge = intersection_of_length2(all_path[i],reversed_all_path[j])#可能产生对头冲突的边
            for edge in same_edge:
                node1, node2 = edge[0],edge[1]
                node_time_i = node_info.plane_time[i][1]#飞机i经过的节点及时间
                timei1 = [x[1] for x in node_time_i if x[0] == node1]
                timei2 = [x[1] for x in node_time_i if x[0] == node2]

                node_time_j = node_info.plane_time[j][1]  # 飞机j经过的节点及时间
                timej1 = [x[1] for x in node_time_j if x[0] == node1]
                timej2 = [x[1] for x in node_time_j if x[0] == node2]
                if (timei1>timej1 and timei2>timej2) or (timei1<timej1 and timei2<timej2):
                    continue
                head_Conflict.append([i, timei1[0], timei2[0],j,timej1[0],timej2[0], edge])
    return head_Conflict

def tailgating_Conflict_Detection(node_info,all_path):#追尾冲突，与对头冲突大部分相同
    tailgating_Conflict = []
    for i in range(len(all_path) - 1):  # 飞机i与后面所有的飞机进行匹配
        for j in range(i + 1, len(all_path)):
            same_edge = intersection_of_length2(all_path[i], all_path[j])  # 可能产生对头冲突的边
            for edge in same_edge:
                node1, node2 = edge[0], edge[1]
                node_time_i = node_info.plane_time[i][1]  # 飞机i经过的节点及时间

                # timei1 = [x[1] for x in node_time_i if x[0] == node1]
                #                 # timei2 = [x[1] for x in node_time_i if x[0] == node2]
                #                 #
                #                 # node_time_j = node_info.plane_time[j][1]  # 飞机j经过的节点及时间
                #                 # timej1 = [x[1] for x in node_time_j if x[0] == node1]
                #                 # timej2 = [x[1] for x in node_time_j if x[0] == node2]

                timei1 = node_info.nodelist[node1][1].searchTimeById(i)
                timei2 = node_info.nodelist[node2][1].searchTimeById(i)

                timej1 = node_info.nodelist[node1][1].searchTimeById(j)
                timej2 = node_info.nodelist[node2][1].searchTimeById(j)

                if (timei1 > timej1 and timei2 > timej2) or (timei1 < timej1 and timei2 < timej2):
                    continue
                tailgating_Conflict.append([i, timei1, timei2,j,timej1,timej2, edge])
    return tailgating_Conflict

def node_Conflict_Resolution(conflictInfo, speed):#[[node,[plane1,time],[plane2,time]],…………]
    planeAndWaitTime = []

    used=[]
    for i in conflictInfo:

        earlyPlane = i[1][0]
        earlyTime = i[1][1]
        latePlane = i[2][0]
        lateTime = i[2][1]

        earlySpeed = speed[earlyPlane]
        time_interval = SAFE_DISTANCE/earlySpeed
        waitTime =math.ceil( earlyTime + time_interval - lateTime )
        planeAndWaitTime.append([latePlane,waitTime])
        used.append(earlyPlane)
        used.append(latePlane)

    return planeAndWaitTime

def head_Conflict_Resolution(conflictInfo, speed):
    return []

def tailgating_Conflict_Resolution(conflictInfo, speed):
    planeAndWaitTime = []
    for conflict in conflictInfo:
        [i, timei1, timei2, j, timej1, timej2, edge] = conflict
        [node1,node2] = edge
        if timei1<timej1:
            earlyPlane, latePlane= i,j
            earlyPlaneTime1, earlyPlaneTime2,latePlaneTime1,latePlaneTime2 = timei1, timei2,timej1,timej2
        else :
            earlyPlane, latePlane = j, i
            earlyPlaneTime1, earlyPlaneTime2, latePlaneTime1, latePlaneTime2 = timej1, timej2,timei1, timei2
        earlySpeed = speed[earlyPlane]
        time_interval = SAFE_DISTANCE/earlySpeed
        waitTime = earlyPlaneTime2 + time_interval - latePlaneTime2

        tempLatePlane=[x[0] for x in planeAndWaitTime]
        if latePlane in tempLatePlane:
            continue
        planeAndWaitTime.append([latePlane, waitTime])

    return planeAndWaitTime


if __name__ == '__main__':

    global SAFE_DISTANCE  # 安全距离
    SAFE_DISTANCE = 200

    data = readin("data/5")
    ap = AirportPlan(data.plan)

    node = [x[0] for x in data.coordinate]  # 所有点的序号
    node_info = NodeInfo(node)

    WTGeneration=[]#每一代的等待时间
    LastTimeGeneration=[]
    DeltaGeneration=[]
    MakespanGeneration=[]
    OmigaGeneration=[]
    PathLengthGeneration=[]#每一代滑行路径长度
    bestAverageWaitTime = -1
    ConflictNumGeneration=[]
    TimeGeneration=[]
    startTime=time.time()
    gen=0

    while gen <max_generation:
        print(gen)
        for i in range(len(ap.num)):
            ap.path.append(ACO.ACO_algrithm(data, i))
            vertex_time = ap.calculate_time(ap.path[i], i)
            node_info.__add__(i, vertex_time)

        # planeAndWaitTime=[[1,900],[2,300]]
        # ap.wait(planeAndWaitTime)
        # print(ap.path_time)

        flag=True
        nodeDetectTime=0
        conflictNum = 0
        while(True):

            conflict1 = node_Conflict_Detection(node_info, data.plan)
            if len(conflict1) != 0:
                conflictNum += 1
                for i in range(len(conflict1)):
                    firstPlane,secondPlane=conflict1[i][1][0],conflict1[i][2][0]
                    if(ap.priority[firstPlane]<ap.priority[secondPlane]):
                        conflict1[i][1],conflict1[i][2] = conflict1[i][2],conflict1[i][1]

                planeAndWaitTime = node_Conflict_Resolution(conflict1, ap.speed)
                ap.wait(planeAndWaitTime)
                # print("node")
              #  print(ap.wait_time)
                continue

            # conflict2 = head_Conflict_Detection(node_info, ap.path)
            # if len(conflict2) != 0:
            #     planeAndWaitTime = head_Conflict_Resolution(conflict2, ap.speed)
            #     ap.wait(planeAndWaitTime)
            #     print("head")
            #     continue

            conflict3 = tailgating_Conflict_Detection(node_info, ap.path)
            if len(conflict3) != 0:
                conflictNum += 1
                planeAndWaitTime = tailgating_Conflict_Resolution(conflict3, ap.speed)
                ap.wait(planeAndWaitTime)
                print(sum(ap.wait_time))
                print("tail")
                continue
            break
            #print(sum(ap.wait_time))
            break
        gen += 1
        ConflictNumGeneration.append(conflictNum)
        travelTimeList = [[x[0][1], x[-1][1]] for x in ap.path_time]
        travelTime = [x[1] - x[0] for x in travelTimeList]
        lastTime = max(x[1] for x in travelTimeList)
        delta = 0;
        omiga = 0;
        makespan=sum([i[1]-i[0] for i in travelTimeList])
        TimeGeneration.append(time.time() - startTime)
        l = 0
        for p in ap.path:
            l += ap.calculate_length(p)
        PathLengthGeneration.append(l)

        for x in range(len(ap.finish_time)):
            delta += (travelTimeList[x][1] - ap.finish_time[x]) * (travelTimeList[x][1] - ap.finish_time[x]);
            omiga += ap.wait_time[x] * ap.wait_time[x]
        AverageWaitTime = sum(ap.wait_time) / len(ap.num)
        if (len(WTGeneration) == 0):  # 平均等待时间
            WTGeneration.append(AverageWaitTime)
            bestAverageWaitTime = AverageWaitTime
        else:
            bestAverageWaitTime = min(AverageWaitTime, bestAverageWaitTime)
            WTGeneration.append(bestAverageWaitTime)

        if (len(LastTimeGeneration) == 0):  # 总体滑行时间
            LastTimeGeneration.append(lastTime)
            bestLastTime = lastTime
        else:
            bestLastTime = min(bestLastTime, lastTime)
            LastTimeGeneration.append(bestLastTime)

        if (len(DeltaGeneration) == 0):
            DeltaGeneration.append(delta)
            bestDelta = delta
        else:
            bestDelta = min(bestDelta, delta)
            DeltaGeneration.append(bestDelta)

        if (len(OmigaGeneration) == 0):
            OmigaGeneration.append(omiga)
            bestOmiga = omiga
        else:
            bestOmiga = min(bestOmiga, omiga)
            OmigaGeneration.append(bestOmiga)

        if(len(MakespanGeneration)==0):
            MakespanGeneration.append(makespan)
            bestMakespan=makespan;
        else:
            makespan=min(makespan,bestMakespan)
            MakespanGeneration.append(bestMakespan)

        ap.path.clear()
        ap.path_time.clear()
        ap.wait_time=[0]*len(ap.num)
        node_info=NodeInfo(node)

    with open("data/0302/ acoWaitingTime.csv", 'a', newline='') as csvfile:  # 平均等待时间
        writer = csv.writer(csvfile)
        writer.writerow(WTGeneration)

    with open("data/0302/ acoLastTime.csv", 'a', newline='') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(LastTimeGeneration)

    with open("data/0302/ acoMakespan.csv", 'a', newline='') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(MakespanGeneration)

    with open("data/0302/ acoPathLength.csv", 'a', newline='') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(PathLengthGeneration)

    with open("data/0302/ acoConflictNum.csv", 'a', newline='') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(ConflictNumGeneration)

    with open("data/0302/ acoTime.csv", 'a', newline='') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(TimeGeneration)